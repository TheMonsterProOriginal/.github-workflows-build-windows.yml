#define MyAppName "AdBloker Local"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "AdBloker"

[Setup]
AppId={{C7B5F8AC-3A5D-4E02-B9E5-4CCB8BEA15A1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\AdBloker Local
DefaultGroupName=AdBloker Local
OutputDir=..\dist
OutputBaseFilename=AdBloker-Setup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=admin
WizardStyle=modern
UninstallDisplayIcon={app}\AdBloker.exe
ArchitecturesInstallIn64BitMode=x64
DisableProgramGroupPage=yes

[Files]
Source: "..\AdBloker\bin\Release\AdBloker.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\redist\NDP472-Web.exe"; DestDir: "{tmp}"; Flags: deleteafterinstall

[Icons]
Name: "{autodesktop}\AdBloker Local"; Filename: "{app}\AdBloker.exe"; Tasks: desktopicon
Name: "{group}\AdBloker Local"; Filename: "{app}\AdBloker.exe"

[Tasks]
Name: "desktopicon"; Description: "Crea un collegamento sul desktop"; GroupDescription: "Collegamenti aggiuntivi:"

[Run]
Filename: "{app}\AdBloker.exe"; Description: "Avvia AdBloker Local"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: files; Name: "{app}\hosts.adbloker.backup"

[Code]
function IsDotNet472Installed(): Boolean;
var
  Release: Cardinal;
begin
  Result := RegQueryDWordValue(HKLM, 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', Release) and (Release >= 461808);
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  ResultCode: Integer;
  DotNetInstaller: String;
begin
  Result := '';
  if IsDotNet472Installed() then
    exit;

  DotNetInstaller := ExpandConstant('{tmp}\NDP472-Web.exe');
  if not FileExists(DotNetInstaller) then begin
    Result := 'Il programma di installazione di .NET Framework 4.7.2 non e'' disponibile.';
    exit;
  end;

  WizardForm.StatusLabel.Caption := 'Installazione di .NET Framework 4.7.2...';
  if not Exec(DotNetInstaller, '/quiet /norestart', '', SW_HIDE, ewWaitUntilTerminated, ResultCode) then
    Result := 'Impossibile avviare l''installazione di .NET Framework 4.7.2.'
  else if (ResultCode <> 0) and (ResultCode <> 3010) then
    Result := 'L''installazione di .NET Framework 4.7.2 non e'' riuscita. Codice: ' + IntToStr(ResultCode);
end;