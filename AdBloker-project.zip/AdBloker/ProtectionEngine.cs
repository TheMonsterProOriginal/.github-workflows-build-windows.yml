using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
namespace AdBloker {
 internal sealed class ProtectionEngine {
  private const string Begin="# AdBloker BEGIN", End="# AdBloker END";
  private readonly string hostsPath=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),@"drivers\etc\hosts");
  private readonly string backupPath=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"hosts.adbloker.backup");
  private readonly HashSet<string> defaultDomains=new HashSet<string>(StringComparer.OrdinalIgnoreCase){"doubleclick.net","googlesyndication.com","googleadservices.com","adnxs.com","criteo.com","criteo.net","amazon-adsystem.com","taboola.com","outbrain.com","popads.net","popcash.net","advertising.com","adsrvr.org","scorecardresearch.com","zedo.com","quantserve.com","rubiconproject.com","pubmatic.com","moatads.com"};
  public int BlockedDomains { get; private set; } public bool IsEnabled { get; private set; }
  public ProtectionEngine(){RefreshState();}
    public void Enable(IEnumerable<string> whitelist){ string original=File.Exists(hostsPath)?File.ReadAllText(hostsPath):string.Empty; if(!File.Exists(backupPath))File.WriteAllText(backupPath,original); HashSet<string> allowed=new HashSet<string>(whitelist??Enumerable.Empty<string>(),StringComparer.OrdinalIgnoreCase); List<string> domains=defaultDomains.Where(d=>!allowed.Contains(d)).ToList(); using(StringWriter w=new StringWriter()){w.Write(RemoveManagedSection(original).TrimEnd());w.WriteLine();w.WriteLine();w.WriteLine(Begin);foreach(string d in domains){w.WriteLine("0.0.0.0 "+d);w.WriteLine("0.0.0.0 www."+d);w.WriteLine("::1 "+d);w.WriteLine("::1 www."+d);}w.WriteLine(End);File.WriteAllText(hostsPath,w.ToString());} BlockedDomains=domains.Count;IsEnabled=true; }
  public void Disable(){if(File.Exists(hostsPath))File.WriteAllText(hostsPath,RemoveManagedSection(File.ReadAllText(hostsPath)));IsEnabled=false;BlockedDomains=0;}
  public void RestoreOriginal(){if(File.Exists(backupPath))File.WriteAllText(hostsPath,File.ReadAllText(backupPath));IsEnabled=false;BlockedDomains=0;}
  public void RefreshState(){string text=File.Exists(hostsPath)?File.ReadAllText(hostsPath):string.Empty;IsEnabled=text.IndexOf(Begin,StringComparison.OrdinalIgnoreCase)>=0;string managed=GetManagedSection(text);BlockedDomains=IsEnabled?managed.Split(new[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries).Count(l=>l.StartsWith("0.0.0.0 ",StringComparison.Ordinal)&&!l.StartsWith("0.0.0.0 www.",StringComparison.Ordinal)):0;}
  private static string GetManagedSection(string text){int start=text.IndexOf(Begin,StringComparison.OrdinalIgnoreCase);if(start<0)return string.Empty;int end=text.IndexOf(End,start,StringComparison.OrdinalIgnoreCase);return end<0?text.Substring(start):text.Substring(start,end+End.Length-start);}
  private static string RemoveManagedSection(string text){int start=text.IndexOf(Begin,StringComparison.OrdinalIgnoreCase);if(start<0)return text;int end=text.IndexOf(End,start,StringComparison.OrdinalIgnoreCase);return end<0?text.Substring(0,start):text.Remove(start,end+End.Length-start);}
 }
}